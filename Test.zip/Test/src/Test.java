import java.io.File;
import java.io.FileNotFoundException;
import java.io.PrintWriter;
import java.io.IOException;
import java.util.Scanner;

public class Test {
    private final String defaultOutputName = "output.txt";
    private final String defaultResultName = "result.txt";

    private void results() {
        try (Scanner scannerForAnswers = new Scanner(new File(defaultOutputName));
             Scanner testAnswerScanner = new Scanner(new File(defaultResultName))) {
            System.out.println(" _*_*_*_ program _*_*_*_");
            while ((scannerForAnswers.hasNextLine())) {
                System.out.println(scannerForAnswers.nextLine());
            }
            System.out.println(" _*_*_*_ test _*_*_*_ ");
            while (testAnswerScanner.hasNextLine()) {
                System.out.println(testAnswerScanner.nextLine());
            }
        } catch (FileNotFoundException e) {
            e.printStackTrace();
        }
    }

    private void startTesting(String projectName, int numberOfTest) {
        if (numberOfTest == -1) {

        }
        int testsPassedNum = 0;
        for (int i = 1; i <= numberOfTest; i++) {
            testUpdate(i, projectName);
            startRunning(projectName);
            results();
            if (testResultChecking()) {
                testsPassedNum++;
                System.out.println(" test log " + i + " : " + " is: OK ");
            } else {
                System.out.println(" test log " + i + " : " + "is: ERROR ");
            }
        }
        System.out.println(" your passed test count is: " + testsPassedNum + "\n your failed test count is: " + (numberOfTest - testsPassedNum));
        System.out.println("");
    }

    private boolean testResultChecking() {
        try (Scanner programAnswerScanner = new Scanner(new File(defaultOutputName));
             Scanner testAnswerScanner = new Scanner(new File(defaultResultName))) {
            while ((programAnswerScanner.hasNextLine()) && (testAnswerScanner.hasNextLine())) {
                final String testResultRow = testAnswerScanner.nextLine();
                final String programResultRow = programAnswerScanner.nextLine();
                if (!testResultRow.equals(programResultRow)) {
                    return false;
                }
            }
            return testAnswerScanner.hasNextLine();
        } catch (FileNotFoundException e) {
            e.printStackTrace();
            return false;
        }
    }

    private boolean startRunning(String projectName) {
        final String programsDirectory = "cpp-programs";
        try {
            String pathToMainFile = programsDirectory + "/" + projectName + "/" + "main.cpp";
            Process compilingProcess = Runtime.getRuntime().exec(" g++ " + pathToMainFile);
            while (compilingProcess.isAlive()) {
            }
            Process runInTest = Runtime.getRuntime().exec(" ./a.out");
            while (runInTest.isAlive()) {
            }
            return true;
        } catch (IOException e) {
            e.printStackTrace();
            return false;
        }
    }

    private boolean testUpdate(int testId, String projectName) {
        final String defaultName = "input.txt";
        final String inputTest = "input";
        final String directoryTest = "test-pack";
        final String outputTest = "output";
        String sourceInputDataPath = directoryTest + "/" + projectName + "/" + inputTest + "/test-" + testId + "-in.txt";
        String sourceResultDataPath = directoryTest + "/" + projectName + "/" + outputTest + "/test-" + testId + "-out.txt";
        try (Scanner testInputDataScanner = new Scanner(new File(sourceInputDataPath));
             PrintWriter inputDataWriter = new PrintWriter(new File(defaultName));
             Scanner testResultDataScanner = new Scanner(new File(sourceResultDataPath));
             PrintWriter resultDataWriter = new PrintWriter(new File(defaultResultName));
             PrintWriter programResultFileWriter = new PrintWriter(new File(defaultOutputName))
        ) {
            while (testInputDataScanner.hasNextLine()) {
                inputDataWriter.println(testInputDataScanner.nextLine());
                inputDataWriter.flush();
            }
            while (testResultDataScanner.hasNextLine()) {
                resultDataWriter.println(testResultDataScanner.nextLine());
                resultDataWriter.flush();
            }
            programResultFileWriter.print("");
            programResultFileWriter.flush();
            return true;
        } catch (FileNotFoundException e) {
            e.printStackTrace();
            return false;
        }
    }

    public static void main(String[] args) {
        String projectName = "sum-ab";

        System.out.println("That gonna be right");

        Test main = new Test();
        main.startTesting(projectName, 6);

    }
}